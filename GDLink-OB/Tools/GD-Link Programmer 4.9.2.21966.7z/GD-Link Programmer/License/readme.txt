List of CopyRight files in the licence folder used by the software.

libusb: libusb_license.txt